//Constant for Tumblr OAuth key for use in other files
var oauth = "cFDOxHiYjtdL4D2e7nU6jRYu0gAzF6uYpX5DOgBMV0Vdd7no4L";